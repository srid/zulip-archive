{-# LANGUAGE KindSignatures #-}
{-# LANGUAGE ConstraintKinds #-}
{-# LANGUAGE TypeOperators #-}
{-# LANGUAGE RankNTypes #-}
{-# LANGUAGE GADTs #-}
{-# LANGUAGE DataKinds #-}
{-# LANGUAGE ScopedTypeVariables #-}

module Matrix where

import GHC.TypeLits
import Data.Proxy
-- import Data.Zero

-- (1) Matrix type and type family definition

type NonZero (n :: Nat) = (CmpNat n 0 ~ 'GT)
type ValidDimensions (n :: Nat) (m :: Nat) = (NonZero n, NonZero m)
type KnownDimensions (n :: Nat) (m :: Nat) = (KnownNat n, KnownNat m)

-- Data type representing a type safe matrix based on the inductive
-- biproduct approach.
--
-- NOTE: The 1 >< 1 Matrix is the base case
data Matrix e (c :: Nat) (r :: Nat) where
  Junc :: (ValidDimensions m n, NonZero p) => Matrix e m p -> Matrix e n p -> Matrix e (m + n) p
  Split :: (ValidDimensions m n, NonZero p) => Matrix e p m -> Matrix e p n -> Matrix e p (m + n)
  One :: e -> Matrix e 1 1

instance Show e => Show (Matrix e c r) where
    show (One e) = show e
    show (Split a b) = show a ++ "\n" ++ show b
    show (Junc a b) = show a ++ " " ++ show b

-- (2) Matrix primitive combinators

-- Create a matrix element
one :: e -> Matrix e 1 1
one = One

-- Matrix block algebra 'Junc' operator
junc :: (ValidDimensions m n, NonZero p) => Matrix e m p -> Matrix e n p -> Matrix e (m + n) p
junc = Junc

-- Matrix block algebra 'Split' operator
split :: (ValidDimensions m n, NonZero p) => Matrix e p m -> Matrix e p n -> Matrix e p (m + n)
split = Split

identity22 :: Num e => Matrix e 2 2
identity22 = split (junc (one 1) (one 0)) (junc (one 0) (one 1))

-- Polimorphic identity matrix
identityMatrix :: Integer -> Matrix e n n
identityMatrix = undefined

-- Matrix 'Junc' left injector
i1 :: Matrix e c m -> Matrix e c (m + n)
i1 = undefined

-- Block 'Split' right injector
i2 :: Matrix e c n -> Matrix e c (m + n)
i2 = undefined

-- Obtain the number of columns of a matrix
columns :: forall e c r . KnownNat c => Matrix e c r -> Integer
columns _ = natVal (Proxy :: Proxy c)

-- Obtain the number of rows of a matrix
rows :: forall e c r . KnownNat r => Matrix e c r -> Integer
rows _ = natVal (Proxy :: Proxy r)

